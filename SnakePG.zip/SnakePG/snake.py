import pygame
import copy
import time
import random

class snake:
    def __init__(self):
        self.pg = pygame
        self.copy = copy
        self.time = time
        self.rnd = random
        self.running = True
        self.image = self.pg.image.load("Nokia1100.jpeg")
        self.white = (255,255,255)
        self.red = (255,0,0)
        self.black = (0,0,0)
        self.green = (112,173,71)
        self.screencolor = (148,168,131)
        self.screencord = (181,130,137,100)
        self.gamecord = (181,137,137,92)
        self.gamecordi = (182,138,135,90)
        self.score = 0
        self.snakecord = [[212,198],[212,201],[212,204],[212,207]]
        self.direction = "up"
        self.foodpos = [[0,0],[0,0],[0,0],[0,0],[0,0]]
        self.gamestat = 1
        self.mouse = (0,0)
        self.yesarea = [181,219,201,228]
        self.noarea = [296,219,317,228]
    
    def generatefood(self,i):
        genfood = True
        while genfood:
            self.foodpos[i][0]=self.rnd.randint(0,44)*3+182
            self.foodpos[i][1]=self.rnd.randint(0,29)*3+138
            # check if food in snake position
            for snakepart in self.snakecord:
                if snakepart != self.foodpos[i]:
                    genfood = False
                    break
    
    def isareaclicked(self,area):
        if self.mouse[0]>area[0] and self.mouse[0]<area[2] and self.mouse[1]>area[1] and self.mouse[1]<area[3]:
            return True
        else:
            return False

    def gameinit(self):
        self.pg.init()
        self.pg.display.set_caption("Snake Game")
        self.screen = self.pg.display.set_mode((500,500))
        for i in range(5):
            self.generatefood(i)

    def resetgame(self):
        self.snakecord = [[212,198],[212,201],[212,204],[212,207]]
        self.mouse = (0,0)
        self.foodpos = [[0,0],[0,0],[0,0],[0,0],[0,0]]
        self.gamestat = 1
        self.score = 0
        self.direction = "up"
        for i in range(5):
            self.generatefood(i)

    def displaytext(self,msg,size,color,x,y):
        sys_font = self.pg.font.SysFont("Courier New",size)
        text = sys_font.render(msg,0,color)
        x,y = x-text.get_width()//2, y-text.get_height()//2
        self.screen.blit(text,(x,y))

    def gamecheck(self):
        if self.snakecord[0] in self.snakecord[1:]:
            self.pg.mixer.music.load('gameover.wav')
            self.pg.mixer.music.play(0)
            self.gamestat = 0

    def capturefood(self):
        for i in range(5):
            if self.snakecord[0]==self.foodpos[i]:
                self.pg.mixer.music.load('capture.wav')
                self.pg.mixer.music.play(0)
                self.generatefood(i)
                self.snakecord.append([0,0])
                self.score = self.score+50

    def updatesnake(self):
        i = len(self.snakecord)-1
        while i>0:
            self.snakecord[i] = self.copy.deepcopy(self.snakecord[i-1])
            i-=1
        if self.direction == "up":
            self.snakecord[0][1]= 225 if self.snakecord[0][1] == 138 else (self.snakecord[0][1]-3)
        elif self.direction == "down":
            self.snakecord[0][1]= 138 if self.snakecord[0][1] == 225 else (self.snakecord[0][1]+3)
        elif self.direction == "left":
            self.snakecord[0][0]= 314 if self.snakecord[0][0] == 182 else (self.snakecord[0][0]-3)
        elif self.direction == "right":
            self.snakecord[0][0]= 182 if self.snakecord[0][0] == 314 else (self.snakecord[0][0]+3)
        self.capturefood()
        self.gamecheck()

    def updatedirection(self,event):
        if event.key == self.pg.K_LEFT and self.direction!="right":
            self.direction = "left"
        elif event.key == self.pg.K_RIGHT and self.direction!="left":
            self.direction = "right"
        elif event.key == self.pg.K_UP and self.direction!="down":
            self.direction = "up"
        elif event.key == self.pg.K_DOWN and self.direction!="up":
            self.direction = "down"

    def displaysnake(self):
        # show snake
        for part in self.snakecord:
            snakepart = (part[0],part[1],3,3)
            self.pg.draw.rect(self.screen,self.black,snakepart)
        # show head
        head = (self.snakecord[0][0],self.snakecord[0][1],3,3)
        self.pg.draw.rect(self.screen,self.red,head)
    
    def displayfood(self):
        for i in range(5):
            foodcord = (self.foodpos[i][0],self.foodpos[i][1],3,3)
            self.pg.draw.rect(self.screen,self.red,foodcord)

    def displaygame(self):
        self.screen.blit(self.image,(0,0))
        self.pg.draw.rect(self.screen,self.screencolor,self.screencord)
        self.pg.draw.rect(self.screen,self.black,self.gamecord)
        self.pg.draw.rect(self.screen,self.screencolor,self.gamecordi)
        self.displaytext("Snake Game",10,self.black,214,133)
        self.displaytext("Score: "+str(self.score),10,self.black,285,133)
        if self.gamestat == 1:
            self.displaysnake()
            self.displayfood()
            self.updatesnake()
        else:
            self.displaytext("Game Over",20,self.black,250,180)
            self.displaytext("Restart",12,self.black,250,210)
            self.displaytext("Yes",10,self.black,192,224)
            self.displaytext("No",10,self.black,308,224)
            if self.isareaclicked(self.yesarea):
                self.resetgame()
            elif self.isareaclicked(self.noarea):
                self.running=False        

    def playgame(self):
        while self.running:
            self.screen.fill(self.white)
            self.displaygame()
            for event in self.pg.event.get():
                if event.type == self.pg.QUIT:
                    self.running = False
                elif event.type == self.pg.KEYDOWN:
                    self.updatedirection(event)
                elif event.type == self.pg.MOUSEBUTTONDOWN:
                    self.mouse = event.pos
            self.pg.display.update()
            self.time.sleep(0.1)

game = snake()
game.gameinit()
game.playgame()